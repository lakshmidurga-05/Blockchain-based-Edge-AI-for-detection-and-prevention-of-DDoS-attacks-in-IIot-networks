'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class initWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.sutAdapter = sutAdapter;
    }

    async submitTransaction() {
        const args = {
            contractId: 'mitigation',
            contractFunction: 'InitLedger',
            invokerIdentity: 'User1',
            contractArguments: [],
            readOnly: false
        };

        console.log('Invoking InitLedger to initialize the ledger...');

        try {
            await this.sutAdapter.sendRequests(args);
        } catch (error) {
            console.error('Error invoking InitLedger:', error);
        }
    }
}

function createWorkloadModule() {
    return new initWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
