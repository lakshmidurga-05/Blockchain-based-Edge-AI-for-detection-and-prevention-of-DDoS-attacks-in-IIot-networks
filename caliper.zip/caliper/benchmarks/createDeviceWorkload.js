'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class createDeviceWorkload extends WorkloadModuleBase {
    
    //Initializes the workload module instance.
    constructor() {
        super();
        this.txIndex = 0;
        this.ipCount = 1;
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.sutAdapter = sutAdapter;
        this.workerIndex = workerIndex;
        this.roundArguments = roundArguments;
        this.ipCount = workerIndex * 100 + 1; // ensure unique IPs per worker
    }

    generateRandomIP() {
        const subnet = 2 + Math.floor(this.workerIndex % 10);
        return `192.168.${subnet}.${this.ipCount++}`;
    }

    generateRandomName() {
        return `device-${Math.floor(1000 + Math.random() * 9000)}`;
    }

    generateRandomType() {
        const types = ["Sensor", "Controller", "Actuator", "Meter", "Switch", "Motor", "Panel", "Reader", "Detector"];
        const index = Math.floor(Math.random() * types.length);
        return types[index];
    }

    async submitTransaction() {
        const ip = this.generateRandomIP();
        const name = this.generateRandomName();
        const type = this.generateRandomType();

        console.log(`Registering device => IP: ${ip}, Name: ${name}, Type: ${type}`);

        const args = {
            contractId: 'mitigation',
            contractFunction: 'RegisterDevice',
            invokerIdentity: 'User1',
            contractArguments: [ip, name, type], // Add "active" if chaincode expects state
            timeout: 30
        };

        try {
            await this.sutAdapter.sendRequests(args);
        }
        catch (error) {
            console.error(`Error registering device with IP ${ip}:`, error);
        }
    }
}


function createWorkloadModule() {
    return new createDeviceWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
