'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class DeleteDeviceWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.sutAdapter = sutAdapter;
        this.workerIndex = workerIndex;
        this.ipCount = workerIndex * 100 + 1; // each worker starts with its own offset
        this.ipBase = '192.168.0.';
    }

    generateBlockedIP() {
        const subnet = 0 + (this.workerIndex % 10);
        return `${this.ipBase}${subnet}.${this.ipCount++}`;
    }

    async submitTransaction() {
        const ip = this.generateBlockedIP();

        const args = {
            contractId: 'mitigation',
            contractFunction: 'DeleteDevice',
            invokerIdentity: 'User1',
            contractArguments: [ip]
        };

        console.log(`Attempting to delete blocked device with IP: ${ip}`);

        try {
            await this.sutAdapter.sendRequests(args);
        }
        
        catch (error) {
            console.error(`Error deleting device with IP ${ip}:`, error);
        }
    }
}

function createWorkloadModule() {
    return new DeleteDeviceWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
