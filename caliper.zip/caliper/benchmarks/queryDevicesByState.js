'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class QueryDevicesByStateWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.sutAdapter = sutAdapter;
        this.roundArguments = roundArguments;
        this.stateToQuery = roundArguments.state || 'active'; // Default to 'active' if not set
    }

    async submitTransaction() {
        const args = {
            contractId: 'mitigation',
            contractFunction: 'QueryDevicesByState',
            invokerIdentity: 'User1',
            contractArguments: [this.stateToQuery],
            readOnly: true
        };

        console.log(`Querying devices with state: "${this.stateToQuery}"`);

        try {
            const result = await this.sutAdapter.sendRequests(args);
            console.log(`Query result for state "${this.stateToQuery}":`, result.toString());
        }
        catch (error) {
            console.error(`Error querying devices with state "${this.stateToQuery}":`, error);
        }
    }
}

function createWorkloadModule() {
    return new QueryDevicesByStateWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
