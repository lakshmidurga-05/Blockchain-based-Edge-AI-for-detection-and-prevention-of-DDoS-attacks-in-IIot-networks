'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class CheckDeviceWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.sutAdapter = sutAdapter;
        this.workerIndex = workerIndex;
        this.ipCount = workerIndex * 10 + 1; // unique offset
        this.ipBase = '192.168.0.'; // define base for IPs
        this.state = roundArguments.state || 'active'; // configurable from benchmark file
    }

    generateKnownIP() {
        return `${this.ipBase}${this.ipCount++}`;
    }

    async submitTransaction() {
        const ip = this.generateKnownIP();

        const args = {
            contractId: 'mitigation',
            contractFunction: 'DeviceExists',
            invokerIdentity: 'User1',
            contractArguments: [this.state, ip],
            readOnly: true
        };

        onsole.log(`Checking if device exists in state "${this.state}" with IP: ${ip}`);

        try {
            const result = await this.sutAdapter.sendRequests(args);
            console.log(`DeviceExists result for IP ${ip}:`, result.toString());
        }
        catch (error) {
            console.error(`Error checking device with IP ${ip}:`, error);
        }
    }
}

function createWorkloadModule() {
    return new CheckDeviceWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
