'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class BlockDeviceWorkload extends WorkloadModuleBase {
    constructor() {
        super();
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        this.sutAdapter = sutAdapter;
        this.workerIndex = workerIndex;
        this.ipCount = workerIndex * 10 + 1; // unique offset per worker
        this.ipBase = '192.168.0.';  // define base for IPs
    }

    generateExistingIP() {
        return `${this.ipBase}${this.ipCount++}`;
    }

    async submitTransaction() {
        const ip = this.generateExistingIP();

        const args = {
            contractId: 'mitigation',
            contractFunction: 'BlockDevice',
            invokerIdentity: 'User1',
            contractArguments: [ip]
        };

        console.log(`Invoking BlockDevice for IP: ${ip}`);

        try {
            await this.sutAdapter.sendRequests(args);
        }
        catch (error) {
            console.error(`Error blocking device with IP ${ip}:`, error);
        }
    }
}

function createWorkloadModule() {
    return new BlockDeviceWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;
